#ifndef __LIB_REPLACE_REPLACE_TESTSUITE_H__
#define __LIB_REPLACE_REPLACE_TESTSUITE_H__

#include <stdbool.h>
struct torture_context;

bool torture_local_replace(struct torture_context *ctx);

#endif /* __LIB_REPLACE_REPLACE_TESTSUITE_H__ */

